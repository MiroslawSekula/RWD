listOfBoxes = [
    {
      name: "Programming in Python",
      level: "Beginer",
      content: "Quod consectetur euis obcaecati sapiente! Eum distinctio veniam eligendi tenetur magnam porro, laborum optio quis amet quam illo optio eum."
      
    },
    {
      name: "Android mobile Development",
      level: "Beginer",
      content: "Quod consectetur euis obcaecati sapiente! Eum distinctio veniam eligendi tenetur magnam porro, laborum optio quis amet quam illo optio eum."
    },
    {
      name: "React.js Workshop",
      level: "Beginer",
      content: "Quod consectetur euis obcaecati sapiente! Eum distinctio veniam eligendi tenetur magnam porro, laborum optio quis amet quam illo optio eum."
    },
    {
      name: "Backend in Node.js",
      level: "Beginer",
      content: "Quod consectetur euis obcaecati sapiente! Eum distinctio veniam eligendi tenetur magnam porro, laborum optio quis amet quam illo optio eum."
    },
    {
      name: "User Experience Design",
      level: "Beginer",
      content: "Quod consectetur euis obcaecati sapiente! Eum distinctio veniam eligendi tenetur magnam porro, laborum optio quis amet quam illo optio eum."
    },
    {
      name: "iOS mobile Development",
      level: "Beginer",
      content: "Quod consectetur euis obcaecati sapiente! Eum distinctio veniam eligendi tenetur magnam porro, laborum optio quis amet quam illo optio eum."
    },
  ];
  
  document.addEventListener("DOMContentLoaded", function() {
    let boxesContainer = document.getElementById("boxes-container");
  
    listOfBoxes.forEach(element => {
      let boxDiv = document.createElement("div");
      let contentDiv = document.createElement("div");
      let contentStyle1Div = document.createElement("div");
      let contentStyle2Div = document.createElement("div");
      let h5 = document.createElement("h5");
      let span_1 = document.createElement("span");
      let span_2 = document.createElement("span");
      let span_3 = document.createElement("span");
      let h6 = document.createElement("h6");
      let p = document.createElement("p");
      let button = document.createElement("button");
  
      boxDiv.className = "box";
      contentDiv.className = "content";
      contentStyle1Div.className = "content-style";
      contentStyle2Div.className = "content-style-2";
      button.className = "btn-box";
      span_1.className = "test circle circle_2";
      span_2.className = "test circle circle_2";
      span_3.className = "test circle circle_2";
  
      h5.innerText = element.name;
      h6.innerText = element.level;
      p.innerText = element.content;
      button.innerText = "View Course";
  
      boxDiv.appendChild(contentDiv);
      boxDiv.appendChild(button);
    
      contentStyle1Div.appendChild(h5);
      
      contentStyle2Div.appendChild(p);
    
      contentDiv.appendChild(contentStyle1Div);
      contentDiv.appendChild(span_1);
      contentDiv.appendChild(span_2);
      contentDiv.appendChild(span_3);
    
      contentDiv.appendChild(h6);
      contentDiv.appendChild(contentStyle2Div);
    
      boxesContainer.appendChild(boxDiv);
    });
    
  });
  